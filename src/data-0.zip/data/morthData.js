// ===== MORTH Road Safety Dashboard Data =====

import mortNationalData from './mort-national.json';
import mortStatesData from './mort-states.json';
import mortDistrictData from './mort-districts.json';
import ircNationalData from './irc-national.json';
import ircStatesData from './irc-states.json';
import ircDistrictData from './irc-districts.json';
import clusterNationalData from './cluster-national.json';
import clusterStatesData from './cluster-states.json';
import clusterDistrictData from './cluster-districts.json';
import schoolsZoneNationalData from './schools-zone-national.json';
import schoolsZoneStatesData from './schools-zone-states.json';
import schoolsZoneDistrictData from './schools-zone-districts.json';

export const MORTH_DATA = {
  summary: mortNationalData.summary,
  states: mortStatesData,
  agencies: mortNationalData.agencies,
  rankings: mortNationalData.rankings,
  bars: mortNationalData.bars
};

export const MORTH_DISTRICT_DATA = mortDistrictData;

const CATEGORY_DISTRICT_CONFIGS = {
  mort: mortDistrictData,
  irc: ircDistrictData,
  'schools-zone': schoolsZoneDistrictData,
  cluster: clusterDistrictData
};

// Build lookup: state name (lowercase) → MORTH state data
const toNumber = (value) => Number(String(value ?? 0).replace(/,/g, '')) || 0;
const toIndianString = (value, fractionDigits = 0) =>
  Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits
  });

const scaleRows = (rows, valueKey, factor) =>
  (rows || []).map((row) => ({
    ...row,
    [valueKey]: Math.max(1, Math.round((row[valueKey] || 0) * factor))
  }));

const scaleState = (state, factor) => ({
  ...state,
  fg_covered: Math.max(1, Math.round((state.fg_covered || 0) * factor)),
  blackspots: Math.max(1, Math.round((state.blackspots || 0) * factor)),
  corridors: Math.max(1, Math.round((state.corridors || 0) * factor)),
  total_fatalities: Math.max(1, Math.round((state.total_fatalities || 0) * factor)),
  total_grievous: Math.max(1, Math.round((state.total_grievous || 0) * factor)),
  total_fg: Math.max(1, Math.round((state.total_fg || 0) * factor)),
  spot_distribution: scaleRows(state.spot_distribution, 'value', factor),
  violations: scaleRows(state.violations, 'count', factor),
  crash_types: scaleRows(state.crash_types, 'count', factor),
  crash_natures: scaleRows(state.crash_natures, 'count', factor)
});

const scaleRankingValue = (value, factor) => {
  if (typeof value !== 'string') return value;
  const normalized = value.replace(/,/g, '');
  const kmMatch = normalized.match(/^([\d.]+)\s*km$/i);
  if (kmMatch) {
    const scaled = Number(kmMatch[1]) * factor;
    return `${toIndianString(scaled, 1)} km`;
  }

  const pureNumber = Number(normalized);
  if (!Number.isNaN(pureNumber)) {
    return toIndianString(Math.round(pureNumber * factor));
  }

  return value;
};

const buildCategoryDataset = (baseDataset, factor) => ({
  summary: {
    total_length_processed: toIndianString(toNumber(baseDataset.summary.total_length_processed) * factor, 1),
    fatal_grievous_covered: toIndianString(toNumber(baseDataset.summary.fatal_grievous_covered) * factor),
    blackspots: toIndianString(toNumber(baseDataset.summary.blackspots) * factor),
    fg_coverage: toIndianString(toNumber(baseDataset.summary.fg_coverage) * factor)
  },
  states: (baseDataset.states || []).map((state) => scaleState(state, factor)),
  agencies: (baseDataset.agencies || []).map((agency) => ({
    ...agency,
    length: toIndianString(toNumber(agency.length) * factor, 1),
    corridors: toIndianString(toNumber(agency.corridors) * factor),
    accidents: toIndianString(toNumber(agency.accidents) * factor),
    fatalities: toIndianString(toNumber(agency.fatalities) * factor)
  })),
  rankings: (baseDataset.rankings || []).map((ranking) => ({
    ...ranking,
    rows: (ranking.rows || []).map((row) => ({
      ...row,
      value: scaleRankingValue(row.value, factor)
    }))
  })),
  bars: (baseDataset.bars || []).map((bar) => ({
    ...bar,
    rows: (bar.rows || []).map((row) => ({
      ...row,
      value: Math.max(1, Math.round((row.value || 0) * factor))
    }))
  }))
});

export const DEFAULT_CATEGORY = 'mort';
export const CATEGORY_OPTIONS = ['mort', 'irc', 'schools-zone', 'cluster'];

const resolveCategoryFactor = (data, fallback) => {
  const factor = Number(data?.scale_factor);
  if (Number.isFinite(factor) && factor > 0) return factor;
  return fallback;
};

const resolveCategoryStates = (statesData, fallbackFactor) => {
  if (Array.isArray(statesData)) return statesData;
  const factor = resolveCategoryFactor(statesData, fallbackFactor);
  return (MORTH_DATA.states || []).map((state) => scaleState(state, factor));
};

const resolveNationalData = (nationalData, fallbackFactor) => {
  const hasFullNationalDataset =
    nationalData &&
    typeof nationalData === 'object' &&
    nationalData.summary &&
    Array.isArray(nationalData.agencies) &&
    Array.isArray(nationalData.rankings) &&
    Array.isArray(nationalData.bars);

  if (hasFullNationalDataset) {
    return {
      summary: nationalData.summary,
      agencies: nationalData.agencies,
      rankings: nationalData.rankings,
      bars: nationalData.bars
    };
  }

  const factor = resolveCategoryFactor(nationalData, fallbackFactor);
  const derived = buildCategoryDataset(MORTH_DATA, factor);
  return {
    summary: derived.summary,
    agencies: derived.agencies,
    rankings: derived.rankings,
    bars: derived.bars
  };
};

const IRC_NATIONAL = resolveNationalData(ircNationalData, 0.86);
const SCHOOLS_ZONE_NATIONAL = resolveNationalData(schoolsZoneNationalData, 0.44);
const CLUSTER_NATIONAL = resolveNationalData(clusterNationalData, 1.15);

const IRC_STATES = resolveCategoryStates(ircStatesData, 0.86);
const SCHOOLS_ZONE_STATES = resolveCategoryStates(schoolsZoneStatesData, 0.44);
const CLUSTER_STATES = resolveCategoryStates(clusterStatesData, 1.15);

export const IRC_DATA = {
  summary: IRC_NATIONAL.summary,
  states: IRC_STATES,
  agencies: IRC_NATIONAL.agencies,
  rankings: IRC_NATIONAL.rankings,
  bars: IRC_NATIONAL.bars
};

export const SCHOOLS_ZONE_DATA = {
  summary: SCHOOLS_ZONE_NATIONAL.summary,
  states: SCHOOLS_ZONE_STATES,
  agencies: SCHOOLS_ZONE_NATIONAL.agencies,
  rankings: SCHOOLS_ZONE_NATIONAL.rankings,
  bars: SCHOOLS_ZONE_NATIONAL.bars
};

export const CLUSTER_DATA = {
  summary: CLUSTER_NATIONAL.summary,
  states: CLUSTER_STATES,
  agencies: CLUSTER_NATIONAL.agencies,
  rankings: CLUSTER_NATIONAL.rankings,
  bars: CLUSTER_NATIONAL.bars
};

export const CATEGORY_DATASETS = {
  mort: MORTH_DATA,
  irc: IRC_DATA,
  'schools-zone': SCHOOLS_ZONE_DATA,
  cluster: CLUSTER_DATA
};

export const getDashboardData = (category = DEFAULT_CATEGORY) =>
  CATEGORY_DATASETS[category] || MORTH_DATA;

const buildStateMap = (states) => {
  const stateMap = {};
  (states || []).forEach((state) => {
    stateMap[state.name.toLowerCase()] = state;
  });
  return stateMap;
};

const CATEGORY_STATE_DATA_MAPS = Object.fromEntries(
  Object.entries(CATEGORY_DATASETS).map(([category, data]) => [category, buildStateMap(data.states)])
);

// Backward-compatible default map (MoRT)
export const STATE_DATA_MAP = CATEGORY_STATE_DATA_MAPS.mort;

export const getStateDataMap = (category = DEFAULT_CATEGORY) =>
  CATEGORY_STATE_DATA_MAPS[category] || STATE_DATA_MAP;

export const KNOWN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'NCT of Delhi', 'Jammu and Kashmir', 'Ladakh', 'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Lakshadweep', 'Puducherry'
];

export const SYNONYMS = {
  nctofdelhi: 'delhi', delhi: 'delhi',
  uttaranchal: 'uttarakhand', orissa: 'odisha'
};

const CHART_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
const CHART_COLORS = ['#3b9be0', '#f45b85', '#f6a340'];
const MONTH_WEIGHTS = [0.12, 0.14, 0.16, 0.17, 0.19, 0.22];

const normalizeToArray = (total, weights) => {
  if (!total || total <= 0) return weights.map(() => 0);

  const raw = weights.map((w) => Math.round(total * w));
  const diff = total - raw.reduce((sum, value) => sum + value, 0);
  raw[raw.length - 1] += diff;
  return raw;
};

const buildSeriesByState = (states) => {
  const sorted = [...states].sort((a, b) => b.fg_covered - a.fg_covered);
  const rows = sorted.slice(0, 3);
  return rows.map((state, idx) => ({
    label: state.name,
    color: CHART_COLORS[idx],
    state
  }));
};

const buildComparisonCardData = (seriesRows) => {
  const [a, b, c] = seriesRows.map((row) => row.state);

  return {
    bars: [
      {
        title: 'Black Corridors',
        max: Math.max(a.corridors, b.corridors, c.corridors),
        values: [a.corridors, b.corridors, c.corridors]
      },
      {
        title: 'Fatal + Grievous Covered',
        max: Math.max(a.fg_covered, b.fg_covered, c.fg_covered),
        values: [a.fg_covered, b.fg_covered, c.fg_covered]
      },
      {
        title: 'Blackspots',
        max: Math.max(a.blackspots, b.blackspots, c.blackspots),
        values: [a.blackspots, b.blackspots, c.blackspots]
      },
      {
        title: 'Fatalities',
        max: Math.max(a.total_fatalities, b.total_fatalities, c.total_fatalities),
        values: [a.total_fatalities, b.total_fatalities, c.total_fatalities]
      }
    ],
    pies: [
      {
        title: '% Fatal + Grievous Share',
        values: [a.fg_covered, b.fg_covered, c.fg_covered]
      },
      {
        title: '% Fatality Share',
        values: [a.total_fatalities, b.total_fatalities, c.total_fatalities]
      },
      {
        title: '% Grievous Share',
        values: [a.total_grievous, b.total_grievous, c.total_grievous]
      }
    ]
  };
};

const buildLineSeries = (seriesRows) => {
  return seriesRows.map((row) => ({
    label: row.label,
    color: row.color,
    values: normalizeToArray(row.state.fg_covered, MONTH_WEIGHTS)
  }));
};

const normalizeKey = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

const buildDistrictScaleFactor = (stateName, districtName, category = DEFAULT_CATEGORY) => {
  const districtConfig = CATEGORY_DISTRICT_CONFIGS[category] || MORTH_DISTRICT_DATA;
  const defaultFactor = Number(districtConfig?.default_factor) || 0.2;
  if (!districtName) return defaultFactor;

  const stateKey = normalizeKey(stateName);
  const districtKey = normalizeKey(districtName);
  const stateFactors = districtConfig?.district_factors_by_state?.[stateKey];

  if (stateFactors) {
    const matchedFactor = Object.entries(stateFactors).find(([name]) => normalizeKey(name) === districtKey)?.[1];
    if (typeof matchedFactor === 'number' && matchedFactor > 0) {
      return matchedFactor;
    }
  }

  const hash = districtName
    .toLowerCase()
    .split('')
    .reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
  return 0.12 + (hash % 26) / 100;
};

const scaleDistributionRows = (rows, factor) => {
  return (rows || []).map((row) => ({
    ...row,
    value: Math.max(1, Math.round((row.value || 0) * factor))
  }));
};

const scaleCountRows = (rows, factor) => {
  return (rows || []).map((row) => ({
    ...row,
    count: Math.max(1, Math.round((row.count || 0) * factor))
  }));
};

export const getDistrictData = (stateName, districtName, category = DEFAULT_CATEGORY) => {
  if (!stateName || !districtName) return null;

  const stateDataMap = getStateDataMap(category);
  const baseState = stateDataMap[stateName.toLowerCase()];
  if (!baseState) return null;

  const factor = buildDistrictScaleFactor(stateName, districtName, category);

  return {
    ...baseState,
    name: `${districtName.toUpperCase()} (${baseState.name})`,
    district_name: districtName,
    state_name: baseState.name,
    fg_covered: Math.max(1, Math.round(baseState.fg_covered * factor)),
    blackspots: Math.max(1, Math.round(baseState.blackspots * factor)),
    corridors: Math.max(1, Math.round(baseState.corridors * factor)),
    total_fatalities: Math.max(1, Math.round(baseState.total_fatalities * factor)),
    total_grievous: Math.max(1, Math.round(baseState.total_grievous * factor)),
    total_fg: Math.max(1, Math.round(baseState.total_fg * factor)),
    spot_distribution: scaleDistributionRows(baseState.spot_distribution, factor),
    violations: scaleCountRows(baseState.violations, factor),
    crash_types: scaleCountRows(baseState.crash_types, factor),
    crash_natures: scaleCountRows(baseState.crash_natures, factor)
  };
};

export const getDataByLevel = ({
  category = DEFAULT_CATEGORY,
  stateName = null,
  districtName = null
} = {}) => {
  if (stateName && districtName) {
    return getDistrictData(stateName, districtName, category);
  }

  if (stateName) {
    return getStateDataMap(category)[stateName.toLowerCase()] || null;
  }

  return getDashboardData(category);
};

const asSeriesRow = (state, color) => ({
  label: state.name,
  color,
  state
});

const findNeighborStates = (states, stateName) => {
  const selected = states.find((state) => state.name === stateName);
  if (!selected) return buildSeriesByState(states);

  const byDistance = [...states]
    .filter((state) => state.name !== selected.name)
    .sort((a, b) => {
      const d1 = Math.abs(a.fg_covered - selected.fg_covered);
      const d2 = Math.abs(b.fg_covered - selected.fg_covered);
      return d1 - d2;
    })
    .slice(0, 2);

  const rows = [selected, ...byDistance];
  return rows.map((state, idx) => ({
    label: state.name,
    color: CHART_COLORS[idx],
    state
  }));
};

const getIndiaTopRows = (states) => buildSeriesByState(states);

const buildChartEntry = (label, seriesRows) => {
  const cardData = buildComparisonCardData(seriesRows);
  return {
    label,
    months: CHART_MONTHS,
    series: seriesRows.map((row) => ({ label: row.label, color: row.color })),
    line: {
      title: 'Monthly Fatal + Grievous Trend',
      series: buildLineSeries(seriesRows)
    },
    bars: cardData.bars,
    pies: cardData.pies
  };
};

const buildComparisonChartDataForDataset = (dataset) => {
  const states = dataset?.states || [];
  const chartData = {
    india: buildChartEntry('India (Top States)', getIndiaTopRows(states))
  };

  states.forEach((state) => {
    chartData[state.name.toLowerCase()] = buildChartEntry(
      state.name,
      findNeighborStates(states, state.name)
    );
  });

  return chartData;
};

const CATEGORY_COMPARISON_CHART_DATA = Object.fromEntries(
  Object.entries(CATEGORY_DATASETS).map(([category, dataset]) => [
    category,
    buildComparisonChartDataForDataset(dataset)
  ])
);

// Backward-compatible default comparison data (MoRT)
export const COMPARISON_CHART_DATA = CATEGORY_COMPARISON_CHART_DATA.mort;

export const getComparisonChartData = (stateName, category = DEFAULT_CATEGORY) => {
  const chartData = CATEGORY_COMPARISON_CHART_DATA[category] || COMPARISON_CHART_DATA;
  if (!stateName) return chartData.india;
  return chartData[stateName.toLowerCase()] || chartData.india;
};

export const getComparisonChartDataForSelection = (stateName, districtName, category = DEFAULT_CATEGORY) => {
  const stateLevel = getComparisonChartData(stateName, category);
  if (!stateName || !districtName) return stateLevel;

  const districtData = getDistrictData(stateName, districtName, category);
  if (!districtData) return stateLevel;

  const dataset = getDashboardData(category);
  const states = dataset?.states || [];
  const stateRows = findNeighborStates(states, stateName);
  const selectedState = getStateDataMap(category)[stateName.toLowerCase()];
  const peerState = stateRows.find((row) => row.state.name !== selectedState?.name)?.state || stateRows[1]?.state;

  const districtSeriesRows = [
    asSeriesRow({ ...districtData, name: districtName.toUpperCase() }, CHART_COLORS[0]),
    asSeriesRow(selectedState || stateRows[0].state, CHART_COLORS[1]),
    asSeriesRow(peerState || stateRows[2].state, CHART_COLORS[2])
  ];

  return buildChartEntry(`${districtName}, ${stateName}`, districtSeriesRows);
};
